﻿namespace Sirenix.Utilities
{
    using UnityEngine;

    internal class ProjectPathFinder : ScriptableObject
    {
    }
}