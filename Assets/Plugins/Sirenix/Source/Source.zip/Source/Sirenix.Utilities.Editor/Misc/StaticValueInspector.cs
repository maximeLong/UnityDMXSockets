#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Sirenix.Utilities.Editor
{
    public class StaticValueInspector
    {
        private static readonly Dictionary<string, object> values = new Dictionary<string, object>();

        private StaticValueInspector()
        {

        }

        public static T Inspect<T>(string key, T value)
        {
            T result;
            if (values.ContainsKey(key))
            {
                var obj = values[key];

                if (obj is T)
                {
                    result = (T)obj;
                }
                else
                {
                    try
                    {
                        result = (T)Convert.ChangeType(obj, typeof(T));
                    }
                    catch (InvalidCastException)
                    {
                        result = value;
                        values[key] = result;
                    }
                }
            }
            else
            {
                result = value;
                values[key] = result;
            }

            return result;
        }
    }
}

#endif