﻿//-----------------------------------------------------------------------
// <copyright file="PropertyRangeAttribute.cs" company="Sirenix IVS">
// Copyright (c) Sirenix IVS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
namespace Sirenix.OdinInspector
{
	using System;

	[AttributeUsage(AttributeTargets.Field | AttributeTargets.Property, AllowMultiple = false, Inherited = true)]
	public sealed class PropertyRangeAttribute : Attribute
	{
		public double Min { get; private set; }
		public double Max { get; private set; }

		public PropertyRangeAttribute(double min, double max)
		{
			this.Min = min < max ? min : max;
			this.Max = max > min ? max : min;
		}
	}
}
